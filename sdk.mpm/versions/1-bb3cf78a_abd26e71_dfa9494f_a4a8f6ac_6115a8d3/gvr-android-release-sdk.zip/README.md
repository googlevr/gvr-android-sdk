Google VR SDK
=====================
Copyright (c) 2017 Google Inc.  All rights reserved.

[https://developers.google.com/vr/android/get-started](https://developers.google.com/vr/android/get-started)

Please note, we do not accept pull requests.
